<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'see' );

/** Database username */
define( 'DB_USER', 'see' );

/** Database password */
define( 'DB_PASSWORD', 'nanaananana' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'q>vsFn_t4_#E9 ~M]FyV16|O5$_C~u!MSmdEIny/J|Z}bD/x%QZQU$Js599.bzPx' );
define( 'SECURE_AUTH_KEY',  'I0.i8a7V<<r,B8Qx;jhXBPlOpv~omIwC=?!$ZPXQryZT{Ni_y7GL]vtSV`bR)Y)i' );
define( 'LOGGED_IN_KEY',    '7BBm2d|V%d}g<?ZE,?iH!;Kb>ELt=06^L1_je@5c9=O(u,/piX2i}$m/*Md`.KvM' );
define( 'NONCE_KEY',        'JwGaLpQ66Vv,I*?+;kKW0ZRKGcg~b3%pCgb(ArE3JLheF 6XpnTmSQH.kQ&.ec4W' );
define( 'AUTH_SALT',        ' r^uHWOYRWY|TI/Hi_Z3{l$YQ;YxiBtu&MgbjYMc`z|g$C(Bs]<@P^O=[?fam~o8' );
define( 'SECURE_AUTH_SALT', 'UQe?S#}Nixxw|.9j{lZ(tl 5B-P(8A*|jUi`:WDk.J(m:PVu@U%EqgX%LqCIO;@J' );
define( 'LOGGED_IN_SALT',   '6B($dR.)@e`kfF`LcHeT6,RzjU|KWs.)?7Em5h m,vLn1rY-0tgPO*!qb/w.Rk+:' );
define( 'NONCE_SALT',       ';=343+m#*qW5pz%W?9-<i:t]N|i:Pl?uABrXC[Cq#b}/9M(U5I<F`jGVfgeRA{xS' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
